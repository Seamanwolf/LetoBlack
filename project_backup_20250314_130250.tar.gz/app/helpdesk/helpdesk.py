from flask import Blueprint, render_template, request, redirect, url_for, flash, jsonify, send_from_directory, abort, current_app, session
from app.utils import create_db_connection, login_required, get_user_department, get_notifications_count
from werkzeug.utils import secure_filename
from functools import wraps
import os
from app.extensions import socketio
import mysql.connector
from datetime import datetime
from flask_login import login_required as flask_login_required, current_user

helpdesk_bp = Blueprint('helpdesk', __name__)

@helpdesk_bp.app_template_filter('status_translate')
def status_translate_filter(status):
    translations = {
        'new': 'Новая',
        'open': 'В работе',
        'close': 'Закрытая'
    }
    return translations.get(status, status)


@helpdesk_bp.route('/api/ticket_stats')
def get_ticket_stats():
    # Fetch data from the database or any other source
    data = {
        'labels': ['ПК и ноутбуки', 'Стационарные телефоны', 'Замена/выдача SIM-карт', 'Телевизоры', 'Восстановление паролей', 'Принтеры и переферия', 'Мобильные устройства', 'Программы и сервисы', 'HR'],
        'new_tickets': [10, 15, 7, 5],
        'closed_tickets': [8, 10, 5, 3]
    }
    return jsonify(data)

@helpdesk_bp.route('/helpdesk')
@login_required
def helpdesk_dashboard():
    if current_user.role not in ['admin', 'leader']:
        flash('У вас нет доступа к этой странице', 'danger')
        return redirect(url_for('auth.login'))
    return render_template('helpdesk_dashboard.html')

@helpdesk_bp.route('/api/department_ticket_stats', methods=['GET'])
@login_required
def department_ticket_stats():
    department_id = get_user_department()
    connection = create_db_connection()
    cursor = connection.cursor(dictionary=True)

    cursor.execute("""
        SELECT DATE(creation_date) as date, 
               COUNT(CASE WHEN MONTH(creation_date) = MONTH(CURDATE()) THEN 1 END) as created_this_month,
               COUNT(CASE WHEN status = 'open' THEN 1 END) as in_progress_tickets,
               COUNT(CASE WHEN status = 'close' THEN 1 END) as closed_tickets
        FROM ticket
        WHERE department_id = %s
        GROUP BY DATE(creation_date)
        ORDER BY date
    """, (department_id,))

    stats = cursor.fetchall()
    cursor.close()
    connection.close()

    data = {
        'labels': [row['date'].strftime('%Y-%m-%d') for row in stats],
        'created_this_month': [row['created_this_month'] for row in stats],
        'in_progress_tickets': [row['in_progress_tickets'] for row in stats],
        'closed_tickets': [row['closed_tickets'] for row in stats],
    }

    return jsonify(data)

@helpdesk_bp.route('/helpdesk/new_tickets')
@login_required
def new_tickets():
    if current_user.role not in ['admin', 'leader']:
        flash('У вас нет доступа к этой странице', 'danger')
        return redirect(url_for('auth.login'))

    department_id = get_user_department()

    connection = create_db_connection()
    cursor = connection.cursor(dictionary=True)

    cursor.execute("""
        SELECT t.ticket_id, t.user_id, u.full_name, t.service, t.subservice, t.status, t.creation_date
        FROM ticket t
        JOIN User u ON t.user_id = u.id
        WHERE t.status = 'new'
    """)
    unassigned_tickets = cursor.fetchall()

    cursor.close()
    connection.close()

    current_time = datetime.utcnow()
    return render_template('new_tickets.html', unassigned_tickets=unassigned_tickets, current_time=current_time)

@helpdesk_bp.route('/download_attachment/<filename>', methods=['GET'])
def download_attachment(filename):
    try:
        directory = app.config['UPLOAD_FOLDER']
        app.logger.info(f"Fetching attachment from: {directory}, filename: {filename}")
        return send_from_directory(directory, filename)
    except FileNotFoundError:
        app.logger.error(f"Error fetching attachment: {filename} not found")
        abort(404)

@helpdesk_bp.route('/api/get_ticket_details', methods=['GET'])
def get_ticket_details():
    ticket_id = request.args.get('ticket_id')
    
    if not ticket_id:
        print("No ticket ID provided")
        return jsonify({'error': 'Ticket ID is required'}), 400
    
    conn = create_db_connection()
    cursor = conn.cursor(dictionary=True)

    try:
        cursor.execute("""
            SELECT t.ticket_id, u.full_name, t.service, t.subservice, t.creation_date, t.status, t.assigned_admin_id, t.close_date
            FROM ticket t
            JOIN User u ON t.user_id = u.id
            WHERE t.ticket_id = %s
        """, (ticket_id,))
        ticket_details = cursor.fetchone()

        if not ticket_details:
            print(f"Ticket ID {ticket_id} not found")
            return jsonify({'error': 'Ticket not found'}), 404

        if ticket_details['assigned_admin_id']:
            cursor.execute("SELECT full_name FROM User WHERE id = %s", (ticket_details['assigned_admin_id'],))
            admin_details = cursor.fetchone()
            ticket_details['admin_full_name'] = admin_details['full_name'] if admin_details else None
        else:
            ticket_details['admin_full_name'] = None

        cursor.execute("""
            SELECT m.message_id, m.message_text, m.timestamp, u.full_name as sender_name
            FROM messages m
            JOIN User u ON m.sender_id = u.id
            WHERE m.ticket_id = %s
        """, (ticket_id,))
        messages = cursor.fetchall()

        cursor.execute("""
            SELECT a.attachment_id, a.file_path, a.file_type
            FROM attachments a
            JOIN messages m ON a.message_id = m.message_id
            WHERE m.ticket_id = %s
        """, (ticket_id,))
        attachments = cursor.fetchall()

        for attachment in attachments:
            attachment['file_path'] = ATTACHMENTS_SERVER_URL.rstrip('/') + '/' + attachment['file_path'].lstrip('/')
            print(f"Attachment found: {attachment['file_path']}")

        return jsonify({
            'ticket_details': ticket_details,
            'messages': messages,
            'attachments': attachments
        })
    except mysql.connector.Error as err:
        print(f"Database error: {err}")
        return jsonify({'error': 'Database error'}), 500
    finally:
        cursor.close()
        conn.close()

@helpdesk_bp.route('/uploads/<filename>')
@login_required
def uploaded_file(filename):
    try:
        full_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        print(f"Trying to send file from directory: {full_path}")
        if os.path.exists(full_path):
            return send_from_directory(app.config['UPLOAD_FOLDER'], filename)
        else:
            print(f"File {filename} not found in {app.config['UPLOAD_FOLDER']}")
            return "File not found", 404
    except Exception as e:
        print(f"Error fetching file {filename}: {e}")
        return "File not found", 404


@helpdesk_bp.route('/helpdesk/in_progress_tickets')
@login_required
def in_progress_tickets():
    if current_user.role not in ['admin', 'leader']:
        flash('У вас нет доступа к этой странице', 'danger')
        return redirect(url_for('auth.login'))

    user_id = session.get('id')
    department_id = get_user_department()

    connection = create_db_connection()
    cursor = connection.cursor(dictionary=True)

    cursor.execute("""
        SELECT t.ticket_id, t.user_id, u.full_name, t.service, t.subservice, t.status, t.creation_date
        FROM ticket t
        JOIN User u ON t.user_id = u.id
        WHERE t.status = 'open' AND t.assigned_admin_id = %s
    """, (user_id,))
    my_tickets = cursor.fetchall()

    cursor.close()
    connection.close()

    return render_template('in_progress_tickets.html', my_tickets=my_tickets)


@helpdesk_bp.route('/helpdesk/closed_tickets')
@login_required
def closed_tickets():
    if current_user.role not in ['admin', 'leader']:
        flash('У вас нет доступа к этой странице', 'danger')
        return redirect(url_for('auth.login'))

    user_id = session.get('id')
    department_id = get_user_department()

    connection = create_db_connection()
    cursor = connection.cursor(dictionary=True)

    cursor.execute("""
        SELECT t.ticket_id, t.user_id, u.full_name, t.service, t.subservice, t.status, t.creation_date, t.close_date
        FROM ticket t
        JOIN User u ON t.user_id = u.id
        WHERE t.status = 'close' AND t.assigned_admin_id = %s
    """, (user_id,))
    closed_tickets = cursor.fetchall()

    cursor.close()
    connection.close()

    return render_template('closed_tickets.html', closed_tickets=closed_tickets)


@helpdesk_bp.route('/api/reply_ticket', methods=['POST'])
def reply_ticket():
    print("Reply ticket endpoint called")
    if 'attachment' in request.files:
        reply_attachment = request.files['attachment']
        if reply_attachment.filename != '':
            attachment_filename = secure_filename(reply_attachment.filename)
            attachment_path = os.path.join(app.config['UPLOAD_FOLDER'], attachment_filename)
            reply_attachment.save(attachment_path)
            print(f"Attachment saved at {attachment_path}")
        else:
            attachment_path = None
            print("No attachment filename provided")
    else:
        attachment_path = None
        print("No attachment in request")

    data = request.form
    ticket_id = data.get('ticket_id')
    message = data.get('comment_text')
    admin_id = session.get('id')  # Получаем ID текущего администратора из сессии

    print(f"Received data: ticket_id={ticket_id}, message={message}, admin_id={admin_id}")

    if not ticket_id or not message or not admin_id:
        print("Invalid data")
        return jsonify({'error': 'Invalid data'}), 400

    conn = create_db_connection()
    cursor = conn.cursor()

    try:
        cursor.execute("""
            INSERT INTO messages (ticket_id, sender_id, message_text)
            VALUES (%s, %s, %s)
        """, (ticket_id, admin_id, message))
        message_id = cursor.lastrowid
        print(f"Message inserted with id {message_id}")

        if attachment_path:
            cursor.execute("""
                INSERT INTO attachments (message_id, file_path, file_type)
                VALUES (%s, %s, %s)
            """, (message_id, attachment_path, attachment_path.split('.')[-1]))
            print("Attachment inserted")

        conn.commit()
        print("Reply added successfully")
        return jsonify({'message': 'Reply added successfully'})
    except mysql.connector.Error as err:
        conn.rollback()
        print(f"Database error: {err}")
        return jsonify({'error': 'Database error: {}'.format(err)}), 500
    finally:
        cursor.close()
        conn.close()


@helpdesk_bp.route('/api/reopen_ticket', methods=['POST'])
def reopen_ticket():
    if 'attachment' in request.files:
        reopen_attachment = request.files['attachment']
        if reopen_attachment.filename != '':
            attachment_filename = secure_filename(reopen_attachment.filename)
            attachment_path = os.path.join(app.config['UPLOAD_FOLDER'], attachment_filename)
            reopen_attachment.save(attachment_path)
        else:
            attachment_path = None
    else:
        attachment_path = None

    data = request.form
    ticket_id = data.get('ticket_id')
    reopen_reason = data.get('reopen_reason')
    admin_id = session.get('id')  # Получаем ID текущего администратора из сессии

    if not ticket_id or not reopen_reason or not admin_id:
        return jsonify({'error': 'Invalid data'}), 400

    conn = create_db_connection()
    cursor = conn.cursor()

    try:
        cursor.execute("""
            INSERT INTO messages (ticket_id, sender_id, message_text)
            VALUES (%s, %s, %s)
        """, (ticket_id, admin_id, reopen_reason))
        message_id = cursor.lastrowid

        if attachment_path:
            cursor.execute("""
                INSERT INTO attachments (message_id, file_path, file_type)
                VALUES (%s, %s, %s)
            """, (message_id, attachment_path, attachment_path.split('.')[-1]))

        cursor.execute("""
            UPDATE ticket
            SET status = 'open', assigned_admin_id = %s
            WHERE ticket_id = %s
        """, (admin_id, ticket_id))
        conn.commit()
        return jsonify({'message': 'Ticket reopened successfully'})
    except mysql.connector.Error as err:
        conn.rollback()
        return jsonify({'error': 'Database error: {}'.format(err)}), 500
    finally:
        cursor.close()
        conn.close()


@helpdesk_bp.route('/api/reply_ticket', methods=['POST'])
def handle_reply_ticket():
    try:
        data = request.get_json()
        app.logger.info(f"Received data: {data}")

        ticket_id = data.get('ticket_id')
        admin_id = data.get('admin_id')
        comment_text = data.get('comment_text')
        attachment_path = data.get('attachment_path')

        # Обработка данных
        if attachment_path:
            save_path = os.path.join(app.config['UPLOAD_FOLDER'], os.path.basename(attachment_path))
            app.logger.info(f"Saving attachment to: {save_path}")
            # Пример сохранения содержимого
            with open(save_path, 'w') as file:
                file.write("Example content")

        response = {"status": "success"}
        app.logger.info(f"Sending response: {response}")
        return jsonify(response), 200
    except Exception as e:
        app.logger.error(f"Error handling request: {str(e)}")
        response = {"status": "error", "message": str(e)}
        return jsonify(response), 500


@helpdesk_bp.route('/helpdesk/department_tickets')
@login_required
def department_tickets():
    
    if current_user.role not in ['admin', 'leader']:
        flash('У вас нет доступа к этой странице', 'danger')
        return redirect(url_for('auth.login'))

    connection = create_db_connection()
    cursor = connection.cursor(dictionary=True)

    try:
        # Новые заявки
        cursor.execute("""
            SELECT t.ticket_id, t.user_id, u.full_name, t.service, t.subservice, t.status, t.creation_date, t.close_date, 
                   a.full_name AS admin_full_name,
                   m.message_text
            FROM ticket t
            JOIN User u ON t.user_id = u.id
            LEFT JOIN User a ON t.assigned_admin_id = a.id
            LEFT JOIN messages m ON m.ticket_id = t.ticket_id AND m.message_id = (
                SELECT MIN(message_id) FROM messages WHERE ticket_id = t.ticket_id
            )
            WHERE t.status = 'new'
        """)
        new_tickets = cursor.fetchall()

        # Заявки в работе
        cursor.execute("""
            SELECT t.ticket_id, t.user_id, u.full_name, t.service, t.subservice, t.status, t.creation_date, t.close_date, 
                   a.full_name AS admin_full_name,
                   m.message_text
            FROM ticket t
            JOIN User u ON t.user_id = u.id
            LEFT JOIN User a ON t.assigned_admin_id = a.id
            LEFT JOIN messages m ON m.ticket_id = t.ticket_id AND m.message_id = (
                SELECT MIN(message_id) FROM messages WHERE ticket_id = t.ticket_id
            )
            WHERE t.status = 'open'
        """)
        in_progress_tickets = cursor.fetchall()

        # Закрытые заявки
        cursor.execute("""
            SELECT t.ticket_id, t.user_id, u.full_name, t.service, t.subservice, t.status, t.creation_date, t.close_date, 
                   a.full_name AS admin_full_name,
                   m.message_text
            FROM ticket t
            JOIN User u ON t.user_id = u.id
            LEFT JOIN User a ON t.assigned_admin_id = a.id
            LEFT JOIN messages m ON m.ticket_id = t.ticket_id AND m.message_id = (
                SELECT MIN(message_id) FROM messages WHERE ticket_id = t.ticket_id
            )
            WHERE t.status = 'close'
        """)
        closed_tickets = cursor.fetchall()
    except mysql.connector.Error as err:
        print(f"Ошибка базы данных: {err}")
        flash('Произошла ошибка при загрузке данных', 'danger')
        new_tickets = []
        in_progress_tickets = []
        closed_tickets = []
    finally:
        cursor.close()
        connection.close()

    return render_template('department_tickets.html', 
                           new_tickets=new_tickets, 
                           in_progress_tickets=in_progress_tickets, 
                           closed_tickets=closed_tickets)


@helpdesk_bp.route('/api/start_work', methods=['POST'])
def start_work():
    data = request.get_json()
    ticket_id = data.get('ticket_id')
    admin_id = session.get('user_id')  # Получаем ID текущего администратора

    if not ticket_id or not admin_id:
        return jsonify({'error': 'Invalid data'}), 400

    conn = create_db_connection()
    cursor = conn.cursor()

    try:
        # Обновление статуса заявки и назначение администратора
        cursor.execute("""
            UPDATE ticket SET status = 'open', assigned_admin_id = %s WHERE ticket_id = %s
        """, (admin_id, ticket_id))
        conn.commit()
        return jsonify({'message': 'Ticket taken into work successfully'})
    except mysql.connector.Error as err:
        return jsonify({'error': 'Database error: {}'.format(err)}), 500
    finally:
        cursor.close()
        conn.close()


@helpdesk_bp.route('/helpdesk/take_ticket/<int:ticket_id>', methods=['POST'])
@login_required
def take_ticket(ticket_id):
    user_id = session.get('id')
    connection = create_db_connection()
    cursor = connection.cursor()
    try:
        cursor.execute("""
            UPDATE ticket
            SET status = 'open', assigned_admin_id = %s
            WHERE ticket_id = %s
        """, (user_id, ticket_id))
        connection.commit()
        flash('Ticket taken in work.', 'success')
    except mysql.connector.Error as err:
        connection.rollback()
        flash(f'Error taking ticket: {err}', 'danger')
    finally:
        cursor.close()
        connection.close()
    return redirect(url_for('new_tickets'))

@helpdesk_bp.route('/api/close_ticket', methods=['POST'])
def close_ticket():
    print("Close ticket endpoint called")
    if 'attachment' in request.files:
        close_attachment = request.files['attachment']
        if close_attachment.filename != '':
            attachment_filename = secure_filename(close_attachment.filename)
            attachment_path = os.path.join(app.config['UPLOAD_FOLDER'], attachment_filename)
            close_attachment.save(attachment_path)
            print(f"Attachment saved at {attachment_path}")
        else:
            attachment_path = None
            print("No attachment filename provided")
    else:
        attachment_path = None
        print("No attachment in request")

    data = request.form
    ticket_id = data.get('ticket_id')
    close_comment = data.get('comment_text')
    admin_id = session.get('id')  # Получаем ID текущего администратора из сессии

    print(f"Received data: ticket_id={ticket_id}, close_comment={close_comment}, admin_id={admin_id}")

    if not ticket_id or not close_comment or not admin_id:
        print("Invalid data")
        return jsonify({'error': 'Invalid data'}), 400

    conn = create_db_connection()
    cursor = conn.cursor()

    try:
        cursor.execute("""
            INSERT INTO messages (ticket_id, sender_id, message_text)
            VALUES (%s, %s, %s)
        """, (ticket_id, admin_id, close_comment))
        message_id = cursor.lastrowid
        print(f"Message inserted with id {message_id}")

        if attachment_path:
            cursor.execute("""
                INSERT INTO attachments (message_id, file_path, file_type)
                VALUES (%s, %s, %s)
            """, (message_id, attachment_path, attachment_path.split('.')[-1]))
            print("Attachment inserted")

        cursor.execute("""
            UPDATE ticket
            SET status = 'close', close_date = NOW()
            WHERE ticket_id = %s
        """, (ticket_id,))
        conn.commit()
        print("Ticket closed successfully")
        return jsonify({'message': 'Ticket closed successfully'})
    except mysql.connector.Error as err:
        conn.rollback()
        print(f"Database error: {err}")
        return jsonify({'error': 'Database error: {}'.format(err)}), 500
    finally:
        cursor.close()
        conn.close()

@helpdesk_bp.route('/helpdesk/complete_ticket/<int:ticket_id>', methods=['POST'])
@login_required
def complete_ticket(ticket_id):
    connection = create_db_connection()
    cursor = connection.cursor()
    try:
        cursor.execute("""
            UPDATE ticket
            SET status = 'close', close_date = NOW()
            WHERE ticket_id = %s
        """, (ticket_id,))
        connection.commit()
        flash('Ticket completed.', 'success')
    except mysql.connector.Error as err:
        connection.rollback()
        flash(f'Error completing ticket: {err}', 'danger')
    finally:
        cursor.close()
        connection.close()
    return redirect(url_for('in_progress_tickets'))

@helpdesk_bp.route('/notify_new_ticket')
def notify_new_ticket():
    socketio.emit('new_ticket', {'message': 'Новая заявка'}, namespace='/helpdesk')
    return 'Notification sent', 200

@socketio.on('connect', namespace='/notifications')
def handle_connect():
    print('Client connected')

@socketio.on('disconnect', namespace='/notifications')
def handle_disconnect():
    print('Client disconnected')

def get_unread_notifications_count():
    user_id = session.get('id')  # Получаем текущий ID пользователя из сессии
    if not user_id:
        return 0  # Если ID пользователя отсутствует, возвращаем 0

    connection = create_db_connection()
    cursor = connection.cursor(dictionary=True)

    try:
        # Извлекаем уведомления для текущего пользователя
        cursor.execute("""
            SELECT is_read
            FROM notifications
            WHERE user_id = %s
        """, (user_id,))
        notifications = cursor.fetchall()
        # Считаем количество непрочитанных уведомлений
        return sum(1 for notification in notifications if not notification['is_read'])
    except mysql.connector.Error as err:
        print(f"Ошибка базы данных: {err}")
        return 0
    finally:
        cursor.close()
        connection.close()

@helpdesk_bp.route('/my_department_tickets')
@login_required
def my_department_tickets():
    if current_user.role != 'leader':
        flash('У вас нет доступа к этой странице', 'danger')
        return redirect(url_for('auth.login'))

    department_id = session.get('department')  # Получаем идентификатор департамента из сессии
    print(f"Department ID from session: {department_id}")

    connection = create_db_connection()
    cursor = connection.cursor(dictionary=True)

    try:
        # Новые заявки
        print("Fetching new tickets...")
        cursor.execute("""
            SELECT t.ticket_id, t.user_id, u.full_name AS user_full_name, t.service, t.subservice, t.status, t.creation_date, t.close_date, a.full_name AS admin_full_name
            FROM ticket t
            JOIN User u ON t.user_id = u.id
            LEFT JOIN User a ON t.assigned_admin_id = a.id
            WHERE u.department = %s
        """, (department_id,))
        department_tickets = cursor.fetchall()
        print(f"Department tickets: {department_tickets}")
        cursor.execute("SELECT full_name, department FROM User WHERE id = %s", (session.get('id'),))
        leader_info = cursor.fetchone()
        print(f"Leader info: {leader_info}")
        notifications_count = get_unread_notifications_count()
        print(f"Notifications count: {notifications_count}")

    except mysql.connector.Error as err:
        print(f"Ошибка базы данных: {err}")
        flash('Произошла ошибка при загрузке данных', 'danger')
        department_tickets = []
    finally:
        cursor.close()
        connection.close()

    return render_template(
        'my_department_tickets.html',
        department_tickets=department_tickets,
        leader_info=leader_info,
        notifications_count=notifications_count
    )

@helpdesk_bp.route('/hr_candidates')
@login_required
def hr_candidates():
    current_app.logger.debug("Вход в /hr_candidates - отображаем кандидатов, переданных в ИТ")
    connection = create_db_connection()
    cursor = connection.cursor(dictionary=True)
    try:
        # Новые кандидаты: transferred_to_it=1 и login_pc пустой (то есть данные ИТ ещё не заполнены)
        cursor.execute("""
            SELECT *
            FROM Candidates
            WHERE transferred_to_it = 1
              AND (login_pc IS NULL OR login_pc = '')
            ORDER BY id DESC
        """)
        new_candidates = cursor.fetchall()
        current_app.logger.debug("Найдено new_candidates: %s", new_candidates)

        # Выполненные кандидаты: transferred_to_it=1 и login_pc заполнен (данные ИТ введены)
        cursor.execute("""
            SELECT *
            FROM Candidates
            WHERE transferred_to_it = 1
              AND (login_pc IS NOT NULL AND login_pc != '')
            ORDER BY id DESC
        """)
        done_candidates = cursor.fetchall()
        current_app.logger.debug("Найдено done_candidates: %s", done_candidates)
    except Exception as e:
        current_app.logger.error("Ошибка при запросе hr_candidates: %s", e)
        new_candidates = []
        done_candidates = []
    finally:
        cursor.close()
        connection.close()
    
    return render_template(
        'helpdesk_hr_candidates.html',
        new_candidates=new_candidates,
        done_candidates=done_candidates
    )

from flask import request, jsonify, current_app
from flask_login import login_required, current_user
from datetime import datetime
from app.utils import create_db_connection

@helpdesk_bp.route('/it/candidate/update_data', methods=['POST'])
@login_required
def update_it_candidate_data():
    """
    Универсальный маршрут для обновления IT-данных кандидата.
    Он:
      1. Обновляет в таблице Candidates поля: login_pc, corporate_email, password, crm_id.
      2. На основе данных кандидата (полученных из таблицы Candidates) создаёт (или обновляет) учетную запись в таблице Users.
         Маппинг:
           - login = login_pc
           - full_name = полное имя кандидата
           - Phone = corporate_number (корпоративный номер)
           - department = отдел
           - hire_date = exit_date_1 (дата приема)
           - password = password (из формы)
           - role = "leader", если в позиции содержится "РОП", иначе "user"
      3. Логирует событие передачи кандидата в IT в таблицу CandidateHistory.
    """
    candidate_id = request.form.get('candidate_id')
    login_pc = request.form.get('login_pc')
    corporate_email = request.form.get('corporate_email')
    password = request.form.get('password')
    crm_id = request.form.get('crm_id')
    
    if not candidate_id or not login_pc or not password:
        return jsonify({"success": False, "error": "Отсутствуют обязательные данные"}), 400

    connection = create_db_connection()
    cursor = connection.cursor(dictionary=True)
    try:
        # 1. Обновляем данные кандидата в таблице Candidates
        update_query = """
            UPDATE Candidates
            SET login_pc = %s, corporate_email = %s, password = %s, crm_id = %s
            WHERE id = %s
        """
        cursor.execute(update_query, (login_pc, corporate_email, password, crm_id, candidate_id))
        connection.commit()

        # 2. Получаем данные кандидата для создания/обновления учетной записи
        cursor.execute("""
            SELECT full_name, department, corporate_number, exit_date_1, position
            FROM Candidates
            WHERE id = %s
        """, (candidate_id,))
        candidate = cursor.fetchone()
        if not candidate:
            return jsonify({"success": False, "error": "Кандидат не найден"}), 404

        full_name = candidate['full_name']
        department = candidate['department']
        corporate_number = candidate['corporate_number']
        hire_date = candidate['exit_date_1']  # предполагается, что это дата приема
        position = candidate['position'] or ""
        # Определяем роль: если в позиции содержится "РОП", то leader, иначе user
        role = "leader" if "РОП" in position.upper() else "user"

        # Проверяем, существует ли уже пользователь с таким логином (login = login_pc)
        cursor.execute("SELECT id FROM User WHERE login = %s", (login_pc,))
        user = cursor.fetchone()
        if user:
            # Обновляем запись пользователя
            cursor.execute("""
                UPDATE User
                SET full_name = %s, Phone = %s, department = %s, hire_date = %s, password = %s, role = %s
                WHERE login = %s
            """, (full_name, corporate_number, department, hire_date, password, role, login_pc))
        else:
            # Создаем новую запись
            cursor.execute("""
                INSERT INTO User (login, full_name, Phone, department, hire_date, password, role)
                VALUES (%s, %s, %s, %s, %s, %s, %s)
            """, (login_pc, full_name, corporate_number, department, hire_date, password, role))
        connection.commit()

        # 3. Логирование события передачи в IT
        now = datetime.now()
        log_message = f"Пользователь '{current_user.full_name}' передал в IT: Вход в ПК='{login_pc}', Корпоративная почта='{corporate_email}', CRM id='{crm_id}', корпоративный номер='{corporate_number}'."
        cursor.execute("""
            INSERT INTO CandidateHistory (candidate_id, timestamp, user, field_changed, old_value, new_value)
            VALUES (%s, %s, %s, %s, %s, %s)
        """, (candidate_id, now, current_user.full_name, "transfer_to_IT", "", log_message))
        connection.commit()

        return jsonify({"success": True})
    except Exception as e:
        connection.rollback()
        current_app.logger.error("Ошибка обновления IT данных кандидата: %s", e)
        return jsonify({"success": False, "error": str(e)}), 500
    finally:
        cursor.close()
        connection.close()