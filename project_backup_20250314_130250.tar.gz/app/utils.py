import mysql.connector
from flask import current_app, session, flash, redirect, url_for, request, jsonify, Blueprint
from werkzeug.security import generate_password_hash, check_password_hash
from functools import wraps
from flask_login import login_required as flask_login_required, current_user
from datetime import datetime, timedelta
from dateutil.relativedelta import relativedelta
import json
import traceback

utils_bp = Blueprint('utils', __name__)

def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not current_user.is_authenticated:
            flash("Пожалуйста, авторизуйтесь для доступа к этой странице.", "danger")
            return redirect(url_for('auth.login'))
        return f(*args, **kwargs)
    return decorated_function

def get_user_department():
    return session.get('department')

def create_db_connection():
    try:
        connection = mysql.connector.connect(
            host='192.168.4.14',
            port=3306,
            user='test_user',
            password='password',
            database="Brokers"
        )
        return connection
    except mysql.connector.Error as err:
        current_app.logger.error(f"Ошибка подключения к базе данных: {err}")
        return None

def update_operator_status(user_id, status):
    try:
        connection = create_db_connection()
        cursor = connection.cursor(dictionary=True)
        cursor.execute("UPDATE User SET status = %s, last_active = NOW() WHERE id = %s", (status, user_id))
        connection.commit()
        cursor.execute("SELECT ukc_kc FROM User WHERE id = %s", (user_id,))
        user = cursor.fetchone()
        if user:
            room = user['ukc_kc']
            # Дополнительная логика
            print(f"User {user_id} status updated to {status} in room {room}")
        else:
            print(f"User with ID {user_id} not found.")
    except Exception as e:
        print(f"Error updating operator status: {e}")
    finally:
        cursor.close()
        connection.close()


def authenticate_user(username, password):
    connection = create_db_connection()
    if connection is None:
        current_app.logger.error("Нет подключения к базе данных для аутентификации.")
        return None

    try:
        cursor = connection.cursor(dictionary=True)
        cursor.execute("SELECT id, login, full_name, role, ukc_kc, password FROM User WHERE login = %s AND fired = FALSE", (username,))
        user = cursor.fetchone()
        if user and check_password_hash(user['password'], password):
            return user
        else:
            return None
    except mysql.connector.Error as err:
        current_app.logger.error(f"Ошибка при аутентификации пользователя: {err}")
        return None
    finally:
        cursor.close()
        connection.close()

def get_notifications_count():
    role = session.get('role')  # Роль текущего пользователя

    if not role:
        print("Роль пользователя не установлена в сессии")  # Отладка отсутствия роли
        return 0  # Или другое значение по умолчанию, например, None

    # Подключение к базе данных
    connection = create_db_connection()
    cursor = connection.cursor(dictionary=True)

    # Составление запроса с фильтрацией по роли
    query = """
    SELECT COUNT(*) as count
    FROM Notifications
    WHERE is_for_{role} = TRUE
    """.format(role=role)

    cursor.execute(query)
    result = cursor.fetchone()
    cursor.close()
    connection.close()
    return result['count'] if result else 0

def get_department_weekly_stats(department):
    current_user_id = session.get('id')
    connection = create_db_connection()
    cursor = connection.cursor(dictionary=True)
    
    end_date = datetime.now().date()
    start_date = end_date - timedelta(days=6)
    
    # Формируем список полей для выборки, исключая поля, которые будут взяты за конкретный день
    sum_fields = [
        'deals', 'reservations', 'online_showings', 'offline_showings', 'repeat_showings',
        'new_clients', 'cold_calls', 'adscian', 'adsavito', 'mailouts', 'resales',
        'banners', 'results', 'exclusives', 'stories', 'incoming_cold_calls', 'stationary_calls'
    ]
    
    # Создаем часть SQL-запроса для выборки суммируемых полей
    sum_fields_sql = ",\n".join([f"SUM(Scores.{field}) as {field}" for field in sum_fields])
    
    # Добавляем поля для конкретного дня с условием
    # Предполагается, что за каждый день для пользователя может быть только одна запись
    total_ads_cian_sql = f"MAX(CASE WHEN Scores.date = '{end_date}' THEN Scores.total_ads_cian ELSE 0 END) as total_ads_cian"
    total_ads_avito_sql = f"MAX(CASE WHEN Scores.date = '{end_date}' THEN Scores.total_ads_avito ELSE 0 END) as total_ads_avito"
    
    query = f"""
    SELECT 
        User.id,
        User.full_name,
        {sum_fields_sql},
        {total_ads_cian_sql},
        {total_ads_avito_sql}
    FROM Scores
    JOIN User ON Scores.user_id = User.id
    WHERE User.department = %s 
      AND Scores.date >= %s 
      AND Scores.date <= %s
    GROUP BY User.id, User.full_name
    """
    
    cursor.execute(query, (department, start_date.strftime('%Y-%m-%d'), end_date.strftime('%Y-%m-%d')))
    stats = cursor.fetchall()
    cursor.close()
    connection.close()
    
    return stats

@utils_bp.route('/department_statistics/daily', methods=['POST'])
@login_required
def department_daily_statistics():
    if current_user.role != 'leader':
        return jsonify({'error': 'Доступ запрещен'}), 403

    selected_date = request.form.get('selected_date')
    department_id = session.get('department')

    start_date = datetime.strptime(selected_date, '%Y-%m-%d')
    end_date = start_date

    return get_department_statistics(department_id, start_date, end_date)

@utils_bp.route('/department_statistics/weekly', methods=['POST'])
@login_required
def department_weekly_statistics():
    if current_user.role != 'leader':
        return jsonify({'error': 'Доступ запрещен'}), 403

    department_id = session.get('department')

    # Получаем текущую дату и вычисляем диапазон прошлой недели
    today = datetime.today()
    start_of_week = today - timedelta(days=today.weekday() + 7)  # Начало прошлой недели (понедельник)
    end_of_week = start_of_week + timedelta(days=6)  # Конец прошлой недели (воскресенье)

    start_date = start_of_week
    end_date = end_of_week

    return get_department_statistics(department_id, start_date, end_date)


@utils_bp.route('/department_statistics/monthly', methods=['POST'])
@login_required
def department_monthly_statistics():
    if current_user.role != 'leader':
        return jsonify({'error': 'Доступ запрещен'}), 403

    department_id = session.get('department')
    selected_month = request.form.get('selected_month')  # Format 'YYYY-MM'

    try:
        year, month = map(int, selected_month.split('-'))
    except ValueError:
        return jsonify({'error': 'Некорректный формат месяца.'}), 400

    start_date = datetime(year, month, 1)
    end_date = (start_date + relativedelta(months=1)) - timedelta(days=1)

    return get_department_statistics(department_id, start_date, end_date)


@utils_bp.route('/department_statistics/yearly', methods=['POST'])
@login_required
def department_yearly_statistics():
    if current_user.role != 'leader':
        return jsonify({'error': 'Доступ запрещен'}), 403

    department_id = session.get('department')
    selected_year = request.form.get('selected_year')

    try:
        year = int(selected_year)
    except ValueError:
        return jsonify({'error': 'Некорректный формат года.'}), 400

    start_date = datetime(year, 1, 1)
    end_date = datetime(year, 12, 31)

    return get_department_statistics(department_id, start_date, end_date)


@utils_bp.route('/department_statistics/custom', methods=['POST'])
@login_required
def department_custom_statistics():
    if current_user.role != 'leader':
        return jsonify({'error': 'Доступ запрещен'}), 403

    department_id = session.get('department')
    start_date_str = request.form.get('start_date')
    end_date_str = request.form.get('end_date')

    try:
        start_date = datetime.strptime(start_date_str, '%Y-%m-%d')
        end_date = datetime.strptime(end_date_str, '%Y-%m-%d')
    except ValueError:
        return jsonify({'error': 'Некорректный формат дат.'}), 400

    return get_department_statistics(department_id, start_date, end_date)

def sync_with_google_sheets(data):
    from oauth2client.service_account import ServiceAccountCredentials
    import gspread

    # Настройка авторизации
    scope = ["https://spreadsheets.google.com/feeds", "https://www.googleapis.com/auth/spreadsheets"]
    credentials = ServiceAccountCredentials.from_json_keyfile_name(CREDENTIALS_FILE, scope)
    client = gspread.authorize(credentials)

    # Открытие Google Таблицы
    sheet = client.open_by_url('URL ВАШЕЙ GOOGLE ТАБЛИЦЫ')  # Подставьте URL таблицы
    worksheet = sheet.get_worksheet(0)  # Первый лист

    # Добавление данных
    worksheet.append_row(data)

