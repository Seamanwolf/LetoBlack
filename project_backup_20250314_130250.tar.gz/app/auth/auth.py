from flask import render_template, request, redirect, url_for, flash, session, current_app
from app.auth import auth_bp
from app.utils import authenticate_user, update_operator_status, login_required
from datetime import datetime
from flask_login import login_user
from app.models import User
import mysql.connector 
from werkzeug.security import generate_password_hash, check_password_hash
from functools import wraps
import traceback

@auth_bp.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        
        print(f"INFO: Attempting to authenticate user: {username}")  # Логирование попытки логина
        
        user_data = authenticate_user(username, password)
        
        if user_data:
            print("INFO: User authenticated successfully.")  # Логирование успешной аутентификации
            print(f"DEBUG: User data: {user_data}")  # Логирование данных пользователя
            
            user = User(**user_data)
            login_user(user)
            
            # Установка дополнительных данных в сессию, если необходимо
            session['id'] = user.id
            session['department'] = user_data.get('department')
            session['role'] = user_data.get('role')
            session['ukc_kc'] = user_data.get('ukc_kc')
            session.permanent = True
            
            # Логирование данных сессии
            print(f"INFO: Session ID: {session.get('id')}")
            print(f"INFO: Session Department: {session.get('department')}")
            print(f"INFO: Session Role: {session.get('role')}")
            print(f"INFO: Session UKC_KC: {session.get('ukc_kc')}")
    
            # Перенаправление пользователя по роли
            if user.role == 'operator':
                session['login_time'] = datetime.now()
                update_operator_status(user.id, 'Онлайн')
                return redirect(url_for('callcenter.operator_dashboard'))
            elif user.role == 'admin':
                return redirect(url_for('admin.admin_dashboard'))
            elif user.role == 'leader':
                return redirect(url_for('leader.leader_dashboard'))
            elif user.role == 'backoffice' and user.department == 'Ресепшн':
                return redirect(url_for('reception.reception_dashboard'))
            elif user.role == 'backoffice' and user.department == 'HR':
                return redirect(url_for('hr.candidates_list'))
            else:
                return redirect(url_for('userlist.dashboard'))
        else:
            print("WARNING: Authentication failed.")  # Логирование неудачной аутентификации
            flash("Неверный логин или пароль", "danger")
            return redirect(url_for('auth.login'))
    
    return render_template('login.html')

def create_db_connection():
    try:
        connection = mysql.connector.connect(
            host='192.168.4.14',
            port=3306,
            user='test_user',
            password='password',
            database="Brokers"
        )
        return connection
    except mysql.connector.Error as err:
        current_app.logger.error(f"Ошибка подключения к базе данных на 192.168.4.14:3306: {err}")
        return None

def update_operator_status(operator_id, status):
    connection = create_db_connection()
    if connection is None:
        current_app.logger.error("Нет подключения к базе данных для обновления статуса оператора.")
        return

    try:
        cursor = connection.cursor()
        cursor.execute("UPDATE User SET status = %s WHERE id = %s", (status, operator_id))
        connection.commit()
        current_app.logger.info(f"Статус оператора с ID {operator_id} обновлён на {status}.")
    except mysql.connector.Error as err:
        current_app.logger.error(f"Ошибка при обновлении статуса оператора: {err}")
    finally:
        cursor.close()
        connection.close()

def authenticate_user(username, password):
    connection = create_db_connection()
    if connection is None:
        current_app.logger.error("Нет подключения к базе данных для аутентификации.")
        return None

    try:
        cursor = connection.cursor(dictionary=True)
        cursor.execute(
            "SELECT id, login, full_name, role, ukc_kc, department, password "
            "FROM User WHERE login = %s AND fired = FALSE",
            (username,)
        )
        user = cursor.fetchone()
        if user and check_password_hash(user['password'], password):
            user.pop('password', None)  # Удалить пароль из данных пользователя
            return user  # Возвращаем полный словарь с данными пользователя
        return None
    except mysql.connector.Error as err:
        current_app.logger.error(f"Ошибка при аутентификации пользователя: {err}")
        return None
    finally:
        cursor.close()
        connection.close()

