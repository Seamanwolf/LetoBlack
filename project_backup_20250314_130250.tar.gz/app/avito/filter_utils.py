import time
from playwright.sync_api import sync_playwright

# ===== Настройка ATS =====
ATS_URL = "mysite"
ATS_LOGIN = "admin"
ATS_PASSWORD = "password"

ATS_LOGIN_SELECTOR = "input.input.autocomplete[type='text']"
ATS_PASSWORD_SELECTOR = "input.input.password.autocomplete[type='password']"
ATS_LOGIN_BUTTON_SELECTOR = "button.itl-button.mr-x2.primary"
ATS_HISTORY_SELECTOR = "[data-qa='history']"

WORKSHEET_TO_FILTER_CODE = {
    "Вторичка": "В",
    "Загородка и Коммерция": "ЗК"
}

def update_ats_filter(page, worksheet_title, employee, department, sim):
    filter_code = WORKSHEET_TO_FILTER_CODE.get(worksheet_title, None)
    if not filter_code:
        print(f"Не найден код фильтра для листа {worksheet_title}")
        return

    formatted_sim = format_phone_number(sim)
    if not formatted_sim:
        print("Неверный формат SIM")
        return
    normalized_sim = formatted_sim[1:]

    page.click("[data-qa='history']")
    page.wait_for_timeout(1000)  # ожидание 1 сек

    if page.is_visible("button:has-text('Фильтры')"):
        print("Кнопка 'Фильтры' обнаружена, кликаем для разворачивания панели фильтров.")
        page.click("button:has-text('Фильтры')")
        page.wait_for_timeout(500)

    print("Кликаем по элементу 'Все номера'")
    page.click("span.label-wrapper:has(span.label:text('Все номера'))")
    page.wait_for_timeout(500)

    target_filter_text = f"Авито Pro {department} ({filter_code})"
    print("Начинаем вводить текст:", target_filter_text)
    page.keyboard.type(target_filter_text, delay=100)
    page.wait_for_timeout(500)

    filter_elements = page.locator(f"text={target_filter_text}").element_handles()
    if not filter_elements:
        print(f"Фильтр '{target_filter_text}' не найден.")
        return

    target_element = None
    for handle in filter_elements:
        text_content = handle.inner_text().strip()
        if text_content == target_filter_text:
            target_element = handle
            break
    if not target_element:
        target_element = filter_elements[0]

    li_element = target_element.evaluate_handle("node => node.closest('li.item')")
    if not li_element:
        print("Не удалось найти родительский элемент <li> для фильтра.")
        return

    settings_icon = li_element.as_element().query_selector("div.itl-setup div.svg-settings-24.table-clickable")
    if not settings_icon:
        print("Не найден значок настроек для фильтра.")
        return
    print("Кликаем по значку настроек.")
    settings_icon.click()

    page.wait_for_selector("input.search")
    page.click("input.search")
    page.type("input.search", normalized_sim, delay=100)
    page.wait_for_timeout(500)

    li_items = page.query_selector_all("li.item")
    target_li = None
    for li in li_items:
        li_text = li.inner_text().lower()
        if "номер" not in li_text and "регион" not in li_text:
            target_li = li
            break

    if not target_li:
        print("Не найден элемент с номером для установки чекбокса.")
        return

    li_classes = target_li.get_attribute("class") or ""
    if "active" in li_classes:
        print("Чекбокс уже отмечен (на уровне <li>), настройка фильтра не требуется.")
        return

    checkbox_input = target_li.query_selector("input[type='checkbox']")
    if checkbox_input:
        input_classes = checkbox_input.get_attribute("class") or ""
        if "checked" in input_classes:
            print("Чекбокс уже отмечен (на уровне <input>), настройка фильтра не требуется.")
            return

    checkbox_label = target_li.query_selector("label.itl-checkbox")
    if checkbox_label:
        print("Отмечаем чекбокс для найденного номера.")
        checkbox_label.click(force=True)
        page.wait_for_timeout(500)
    else:
        print("Не удалось найти label чекбокса внутри найденного элемента.")
        return

    page.click("button:has-text('Сохранить')")
    page.wait_for_timeout(500)

    print(f"Фильтр обновлен для {employee} ({department}) с SIM {sim} на листе {worksheet_title}.")
