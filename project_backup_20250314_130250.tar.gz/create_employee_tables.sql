-- Таблица для хранения дополнительных данных о сотрудниках
CREATE TABLE IF NOT EXISTS EmployeeDetails (
    id INT AUTO_INCREMENT PRIMARY KEY,
    employee_id INT NOT NULL,
    has_documents TINYINT DEFAULT 0,
    has_rr TINYINT DEFAULT 0,
    has_site TINYINT DEFAULT 0,
    notes TEXT,
    previous_number VARCHAR(20),
    UNIQUE KEY (employee_id)
);

-- Таблица для хранения фотографий сотрудников
CREATE TABLE IF NOT EXISTS EmployeePhotos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    employee_id INT NOT NULL,
    photo_url VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY (employee_id)
);

-- Таблица для хранения истории изменений пользователей
CREATE TABLE IF NOT EXISTS UserHistory (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    admin_user VARCHAR(100) NOT NULL,
    field_changed VARCHAR(50) NOT NULL,
    old_value TEXT,
    new_value TEXT,
    INDEX (user_id)
);

-- Таблица для хранения истории корпоративных номеров
CREATE TABLE IF NOT EXISTS NumberHistory (
    id INT AUTO_INCREMENT PRIMARY KEY,
    number VARCHAR(20) NOT NULL,
    user_id INT NOT NULL,
    date DATE NOT NULL,
    notes TEXT,
    INDEX (number),
    INDEX (user_id)
);

-- Добавляем колонку в таблицу Candidates для хранения личного телефона, если еще не существует
ALTER TABLE Candidates 
ADD COLUMN IF NOT EXISTS personal_phone VARCHAR(20) DEFAULT NULL;

-- Добавляем индексы для ускорения поиска
ALTER TABLE UserHistory 
ADD INDEX IF NOT EXISTS idx_user_id (user_id);

-- Данный SQL-скрипт создаёт только те таблицы и поля, которые отсутствуют
-- Примечание: Многие поля, которые планировалось добавить в EmployeeDetails,
-- уже существуют в таблице User (documents, rr, site, notes и др.) 