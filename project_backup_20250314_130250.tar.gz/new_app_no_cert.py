from flask import Flask, render_template, request, redirect, url_for, session, flash, jsonify, send_file, send_from_directory, abort
from app.extensions import socketio, scheduler
from datetime import datetime, timedelta, date
import app.socketio_events
from app.auth import auth_bp
from app.admin import admin_bp
from app.leader import leader_bp
from app.helpdesk import helpdesk_bp
from app.backoffice import backoffice_bp
from app.callcenter import callcenter_bp, partial_sync_data
from app.itinvent import itinvent_bp
from app.userlist import userlist_bp
from app.vats import vats_bp
from app.avito import avito_bp
from app.rating import rating_bp
from app.reception import reception_bp
from app.hr import hr_bp
from apscheduler.triggers.cron import CronTrigger
from app.utils import create_db_connection, authenticate_user, update_operator_status
from app.config import SECRET_KEY
from dotenv import load_dotenv
import logging
import os
from flask_login import LoginManager
from app.models import User
import traceback
from datetime import datetime

# Загрузка переменных окружения
load_dotenv('config.env')

# Настройка логирования
logging.basicConfig(level=logging.DEBUG, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

CREDENTIALS_FILE = '/home/user/gapi/GAPI.json'

# Directory to save uploaded files for average deals
AVG_DEALS_UPLOAD_FOLDER = '/home/user/avg_deals_uploads'
try:
    os.makedirs(AVG_DEALS_UPLOAD_FOLDER, exist_ok=True)
except Exception as e:
    logger.error(f'Error creating directory {AVG_DEALS_UPLOAD_FOLDER}: {e}')
ALLOWED_EXTENSIONS = {'xlsx'}

# Создание и настройка LoginManager
login_manager = LoginManager()

@login_manager.user_loader
def load_user(user_id):
    connection = create_db_connection()
    cursor = connection.cursor(dictionary=True)
    cursor.execute("SELECT id, login, full_name, role, ukc_kc, department FROM User WHERE id = %s", (user_id,))
    user_data = cursor.fetchone()
    cursor.close()
    connection.close()
    if user_data:
        return User(**user_data)  # Возвращаем экземпляр User
    else:
        return None
    
def format_date(value, format='%d-%m-%Y'):
    if not value:
        return ""
    # Если значение строковое, пытаемся преобразовать его в datetime
    if isinstance(value, str):
        try:
            dt = datetime.strptime(value, '%Y-%m-%d')
        except Exception as e:
            return value  # Если не удалось, вернуть исходное значение
    else:
        dt = value
    return dt.strftime(format)



def create_app():
    app = Flask(__name__, template_folder='app/templates')
    app.config['SECRET_KEY'] = SECRET_KEY
    app.config['TIME_OF_DAY_NAMES'] = {
        'daily': 'Дневное',
        'nighty': 'Вечернее'
    }
    # Инициализация Flask-Login
    login_manager.init_app(app)
    login_manager.login_view = 'auth.login'  # Обработчик логина

    # Задаём настройки
    app.config['UPLOAD_FOLDER'] = '/home/helpdesk_leto/attach/'
    app.config['AVG_DEALS_UPLOAD_FOLDER'] = '/home/user/avg_deals_uploads'
    app.config['ATTACHMENTS_SERVER_URL'] = "http://192.168.2.112/"

    # Инициализация расширений
    socketio.init_app(app, cors_allowed_origins="*")
    scheduler.init_app(app)
    scheduler.start()

    # Регистрация Blueprint'ов
    app.register_blueprint(auth_bp)
    app.register_blueprint(admin_bp, url_prefix='/admin')
    app.register_blueprint(leader_bp, url_prefix='/leader')
    app.register_blueprint(helpdesk_bp)
    app.register_blueprint(backoffice_bp, url_prefix='/backoffice')
    app.register_blueprint(callcenter_bp)
    app.register_blueprint(vats_bp, url_prefix='/vats')
    app.register_blueprint(avito_bp, url_prefix='/avito')
    app.register_blueprint(itinvent_bp, url_prefix='/itinvent')
    app.register_blueprint(userlist_bp, url_prefix='/userlist')
    app.register_blueprint(rating_bp, url_prefix='/rating')
    app.register_blueprint(hr_bp, url_prefix='/hr')
    app.register_blueprint(reception_bp, url_prefix='/reception')   

    # Примеры данных (в идеале перенести в базу данных)
    tickets = [
        {'id': 1, 'user_full_name': 'Иванов Иван', 'service': 'Сервис 1', 'subservice': 'Подсервис A', 'message': 'Сообщение 1', 'status': 'Новая', 'creation_date': '2023-07-01', 'responsible': 'Петров Петр', 'department': 1},
        {'id': 2, 'user_full_name': 'Сидоров Сидор', 'service': 'Сервис 2', 'subservice': 'Подсервис B', 'message': 'Сообщение 2', 'status': 'В работе', 'creation_date': '2023-07-02', 'responsible': 'Иванов Иван', 'department': 2},
    ]

    users = [
        {"id": 1, "full_name": "Иванов Иван", "department": "Sales", "hire_date": "2020-01-01"},
        {"id": 2, "full_name": "Петров Петр", "department": "Marketing", "hire_date": "2019-06-15"},
        {"id": 3, "full_name": "Сидоров Сидор", "department": "IT", "hire_date": "2018-03-20"},
    ]

    ratings = [
        {"user_id": 1, "full_name": "Иванов Иван", "department": "Sales", "hire_date": "2020-01-01", "quarterly_rating": 4, "avg_deals": 3, "properties": 5, "scripts": 2, "crm_cards": 4, "call_duration": 3, "experience": 4, "avg_score": 3.5},
        {"user_id": 2, "full_name": "Петров Петр", "department": "Marketing", "hire_date": "2019-06-15", "quarterly_rating": 3, "avg_deals": 2, "properties": 4, "scripts": 3, "crm_cards": 5, "call_duration": 2, "experience": 5, "avg_score": 3.4},
        {"user_id": 3, "full_name": "Сидоров Сидор", "department": "IT", "hire_date": "2018-03-20", "quarterly_rating": 5, "avg_deals": 4, "properties": 3, "scripts": 5, "crm_cards": 2, "call_duration": 4, "experience": 3, "avg_score": 3.7},
    ]

    notifications = [
        {'message': 'Новое уведомление 1', 'is_read': False},
        {'message': 'Новое уведомление 2', 'is_read': False},
    ]


    @app.route('/')
    def home():
        return redirect(url_for('auth.login'))

    return app

app = create_app()

initialized = False

def init():
    global initialized
    if not initialized:
        initialized = True

@socketio.on('connect')
def test_connect():
    print('Client connected')

@socketio.on('disconnect')
def test_disconnect():
    print('Client disconnected')

def change_numbers_periodically_with_context():
    with app.app_context():
        try:
            change_numbers_periodically()
        except Exception as e:
            logger.error(f"Ошибка при выполнении change_numbers_periodically: {e}", exc_info=True)

def auto_sync_data_job():
    with app.app_context():
        try:
            partial_sync_data()
        except Exception as e:
            logger.error(f"Ошибка при выполнении partial_sync_data: {e}", exc_info=True)


def initialize_scheduler():
    global scheduler

    # Пример: запускаем partial_sync_data каждые 15 минут, в любое время суток
    job_id = "auto_sync_data_job"
    job_exists = any(job.id == job_id for job in scheduler.get_jobs())
    if not job_exists:
        trigger = CronTrigger(minute='*/15')  # каждые 15 минут
        scheduler.add_job(
            func=auto_sync_data_job,
            trigger=trigger,
            id=job_id,
            replace_existing=True
        )
        logger.info("Добавлена задача auto_sync_data_job в планировщик.")
    else:
        logger.info("Задача auto_sync_data_job уже существует в планировщике.")

    job_exists = any(job.id == "change_numbers_periodically_with_context" for job in scheduler.get_jobs())
    if not job_exists:
        trigger = CronTrigger(minute='*/59', hour='8-21')
        scheduler.add_job(func=change_numbers_periodically_with_context, trigger=trigger, id="change_numbers_periodically_with_context")
        logger.info("Добавлена задача change_numbers_periodically_with_context в планировщик.")
    else:
        logger.info("Задача change_numbers_periodically_with_context уже существует в планировщике.")

def get_month_name(month_number):
    month_names = ['Январь', 'Февраль', 'Март', 'Апрель', 'Май', 'Июнь', 'Июль', 'Август', 'Сентябрь', 'Октябрь', 'Ноябрь', 'Декабрь']
    return month_names[month_number - 1]

def get_user_department():
    return session.get('department')

@app.route('/personnel')
def personnel():
    return render_template('personnel.html')

def sanitize_sheet_name(name):
    invalid_chars = ['\\', '/', '*', '[', ']', ':', '?']
    for char in invalid_chars:
        name = name.replace(char, '_')
    return name[:31]

@app.route('/settings')
def settings():
    return render_template('settings.html')

app.jinja_env.filters['format_date'] = format_date

if __name__ == '__main__':
    initialize_scheduler()
    socketio.run(app, host='0.0.0.0', port=5000, debug=True)
